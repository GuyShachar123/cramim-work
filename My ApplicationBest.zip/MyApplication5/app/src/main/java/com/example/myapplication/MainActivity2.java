package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {

     int topingPrice =5;

     TextView tvWelcome;
     TextView tvPhone;
     CheckBox cbOnions, cbPepperoni, cbHam, cbAnchovies, cbCorn, cbOlives;

     RadioButton rbSmall, rbMedium, rbLarge;
     Button continueToNext;


     String name = "";
     String phone = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);

        tvWelcome = findViewById(R.id.tvWelcome);
        tvPhone = findViewById(R.id.tvPhone);
        cbOnions = findViewById(R.id.cbOnions);
        cbPepperoni = findViewById(R.id.cbPepperoni);
        cbHam = findViewById(R.id.cbHam);
        cbAnchovies = findViewById(R.id.cbAnchovies);
        cbCorn = findViewById(R.id.cbCorn);
        cbOlives = findViewById(R.id.cbOlives);

        rbSmall = findViewById(R.id.rbSmall);
        rbMedium = findViewById(R.id.rbMedium);
        rbLarge = findViewById(R.id.rbLarge);

        continueToNext = findViewById(R.id.btnContinueOrder);
        continueToNext.setOnClickListener(this);

        Intent i = getIntent();
        if (i != null)
        {
            name = i.getStringExtra("NAME");
            phone = i.getStringExtra("Phone");

        }

        tvWelcome.setText("Welcome to my Pizza, "+name);
        tvPhone.setText("your phone is "+phone);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnContinueOrder) {
            String tops = "Your pizza topings are: ";
            String size = "";
            int price = 0;
            if (rbSmall.isChecked())
            {
                price += 40;
                size = "Small";
            }
            else if (rbMedium.isChecked())
            {
                price += 50;
                size = "Medium";
            }
            else if (rbLarge.isChecked())
            {
                price += 60;
                size = "Large";
            }
            else
            {
                Toast.makeText(this, "you must Chosse a size!", Toast.LENGTH_LONG).show();
            }

            if (cbOnions.isChecked())
            {
                price += 5;
                tops += "Onions, ";
            }
            if (cbPepperoni.isChecked())
            {
                price += 5;
                tops += "Pepperoni, ";
            }
            if (cbHam.isChecked())
            {
                price += 5;
                tops += "Ham, ";
            }
            if (cbAnchovies.isChecked())
            {
                price += 5;
                tops += "Anchovies, ";
            }
            if (cbCorn.isChecked())
            {
                price += 5;
                tops += "Corn, ";
            }
            if (cbOlives.isChecked())
            {
                price += 5;
                tops += "Olives, ";
            }
            Intent intent = new Intent(this, MainActivity3.class);
            intent.putExtra("NAME", name);
            intent.putExtra("Phone", phone);
            intent.putExtra("SIZE", size);
            intent.putExtra("TOPPINGS", tops);
            intent.putExtra("PRICE", price);
            startActivity(intent);


        }

    }
}