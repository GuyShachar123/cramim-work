package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    TextView name;
    TextView phone;
    Button goOn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.etName);
        phone = findViewById(R.id.etPhone);
        goOn = findViewById(R.id.btnContinue);
        goOn.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        String nameStr = name.getText().toString();
        String phoneStr = phone.getText().toString();
        if (view.getId() == R.id.btnContinue) {
            if (nameStr.equals("")) {
                Toast.makeText(this, "you must enter name", Toast.LENGTH_LONG).show();
            } else if (phoneStr.equals("")) {
                Toast.makeText(this, "you must enter phoneNumber", Toast.LENGTH_LONG).show();
            } else {
                // Create ONE Intent and put BOTH extras inside it
                Intent i = new Intent(this, MainActivity2.class);
                i.putExtra("NAME", nameStr);
                i.putExtra("Phone", phoneStr);
                startActivity(i);
            }

        }
    }
}