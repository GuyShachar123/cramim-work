package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class MainActivity3 extends AppCompatActivity implements View.OnClickListener {

    TextView tvSummaryName, tvSummaryPhone, tvSummarySize, tvSummaryToppings, tvSummaryPrice, editTextText;
    Button btnConfirmOrder, btnUpdateOrder;
    String send = "";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        tvSummaryName = findViewById(R.id.tvSummaryName);
        tvSummaryPhone = findViewById(R.id.tvSummaryPhone);
        tvSummarySize = findViewById(R.id.tvSummarySize);
        tvSummaryToppings = findViewById(R.id.tvSummaryToppings);
        tvSummaryPrice = findViewById(R.id.tvSummaryPrice);
        editTextText = findViewById(R.id.editTextText);


        btnConfirmOrder = findViewById(R.id.btnConfirmOrder);
        btnUpdateOrder = findViewById(R.id.btnUpdateOrder);
        btnConfirmOrder.setOnClickListener(this);
        btnUpdateOrder.setOnClickListener(this);


        Intent i = getIntent();
        if (i != null) {
            String name = i.getStringExtra("NAME");
            String phone = i.getStringExtra("Phone");
            String size = i.getStringExtra("SIZE");
            String toppings = i.getStringExtra("TOPPINGS");
            int price = i.getIntExtra("PRICE", 0);
            send = "Name: " + name + ", Phone: " + phone + ", Size: " + size + ", Toppings: " + toppings + ", Price:"+price;
            // Display data
            tvSummaryName.setText("Name: " + name);
            tvSummaryPhone.setText("Phone: " + phone);
            tvSummarySize.setText("🍕 Size: " + size);
            tvSummaryToppings.setText("🧀 Toppings: " + toppings);
            tvSummaryPrice.setText("Total Price: ₪" + price);
        }


    }


    public void sendOrderToServer(String dataToSend) {
        // Run on a background thread to prevent NetworkOnMainThreadException
        new Thread(() -> {
            String serverIp = "192.168.4.96";
            int port = 1234;

            try {
                Socket socket = new Socket(serverIp, port);

                // Send data to Python server
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write(dataToSend.getBytes());
                outputStream.flush();

                // Read response from Python server
                InputStream inputStream = socket.getInputStream();
                byte[] buffer = new byte[1024];
                int bytesRead = inputStream.read(buffer);
                    String serverResponse = new String(buffer, 0, bytesRead);
                    runOnUiThread(() -> {
                        editTextText.setText(serverResponse);
                    });


                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }


    public void onClick(View view)
    {
        if (view.getId() == R.id.btnConfirmOrder)
        {
          sendOrderToServer(send);
        }
        else if (view.getId() == R.id.btnUpdateOrder)
        {
            //finish should i think go back to mainActivity 2
            finish();
        }

    }
}