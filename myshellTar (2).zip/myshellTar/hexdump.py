import sys
import os

if not sys.stdin.isatty():
    data = sys.stdin.buffer.read()
    print(data.hex())
else:
    file_path = sys.argv[1]
    with open(file_path, "rb") as f:
        file = f.read()

    print(file.hex())