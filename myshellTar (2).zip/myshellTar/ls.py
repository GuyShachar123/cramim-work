import os
import sys
path_to_list = sys.argv[1]


files = os.listdir(path_to_list)
# i print like this so it will work with grep
for file in files:
    print(file)

    