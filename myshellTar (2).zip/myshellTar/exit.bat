@echo off
python "%~dp0exit.py" %*