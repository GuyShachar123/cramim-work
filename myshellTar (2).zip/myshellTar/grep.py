import os
import sys

search = sys.argv[1]
if not sys.stdin.isatty():
    #from pipe
    for linenum, line in enumerate(sys.stdin, 1):
        if search in line:
            print(f"{linenum}: {line}", end="")
else:
    file_path = sys.argv[2]
    if not os.path.isfile(file_path):
        print(f"Error: File '{file_path}' does not exist.")
        sys.exit(1)
    with open(file_path, "r") as f:
        # enumerate for the line counter
        for linenum, line in enumerate(f, 1):
            if search in line:
                print(f"{linenum}: {line}", end="")