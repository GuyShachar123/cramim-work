@echo off
python "%~dp0help.py" %*