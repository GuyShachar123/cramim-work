import os
import subprocess
import getpass
if __name__ == "__main__":
    file_dir = os.path.dirname(os.path.abspath(__file__))
    #starter dir
    current_directory = os.path.dirname(os.path.abspath(__file__))
    bat_ls = os.path.join(file_dir, "ls.bat")
    bat_grep = os.path.join(file_dir, "grep.bat")
    bat_exit = os.path.join(file_dir, "exit.bat")
    bat_hexdump = os.path.join(file_dir, "hexdump.bat")
    bat_help = os.path.join(file_dir, "help.bat")

    while True:
        send_to_file = False
        output_file = ""
        print(current_directory+ ">>>")
        command = input()

        if "|" in command:
            #i only made it work with grep cause grep only one with input 
            cmd1_part, cmd2_part = command.split("|")
            cmd1 = cmd1_part.strip()
            cmd2 = cmd2_part.strip()
            if cmd1 == "ls" :
                p1 = subprocess.run([bat_ls, current_directory], shell=True,  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                output = p1.stdout
            elif cmd1.startswith("hexdump") and cmd2.startswith("grep "):
                  file = cmd1[8:].strip()
                  f_path =os.path.abspath(os.path.join(current_directory, file))
                  p1 = subprocess.run([bat_hexdump, f_path], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                  output = p1.stdout
            else:
                print("pipe does not support this first args")
            
            if cmd2.startswith("grep "):
                term = cmd2[5:].strip()
                subprocess.run([bat_grep, term], shell=True, input=output)
            elif cmd2.startswith("hexdump"):
                subprocess.run([bat_hexdump], shell=True, input=output)
            else:
                print(f"pipe does not support this second args")
            continue
        
               


        if ">" in command:
             command, file_part = command.split(">")
             command = command.strip()
             output_file = file_part.strip()
             output_file = os.path.abspath(os.path.join(current_directory, output_file))
             send_to_file= True

        if command == "ls":
            bat_ls = os.path.join(file_dir, "ls.bat")
            if send_to_file:
               with open(output_file, "w") as f:
                    subprocess.run([bat_ls, current_directory], shell=True, stdout=f)
                
            else:
                subprocess.run([bat_ls, current_directory], shell=True)
        elif command == '?' or command == "help":
            subprocess.run([bat_help], shell=True)
            
        
        elif command == "hello":
            username = getpass.getuser()
            if send_to_file == True:
                with open(output_file, "w") as f:
                    f.write(f"hello {username}")
            else:
                print(f"hello {username}")
        elif command.startswith("hexdump "):
            file = command[8:].strip()
            f_path =os.path.abspath(os.path.join(current_directory, file))
            if send_to_file:
                with open(output_file, "w") as f:
                    subprocess.run([bat_hexdump, f_path], shell=True, stdout=f)
            else:
                subprocess.run([bat_hexdump, f_path], shell=True)
        elif command.startswith("grep"):      
            file = command.split(" ")[2]    
            term = command.split(" ")[1]
            f_path = os.path.abspath(os.path.join(current_directory, file))
            if send_to_file:
                with open(output_file, "w") as f:
                    subprocess.run([bat_grep, term, f_path], shell=True, stdout=f)
            else:     
                subprocess.run([bat_grep, term, f_path], shell=True)

        elif command.startswith("cd "):
            #to get the things after dir
            dir = command[3:].strip()
            new_dir = os.path.abspath(os.path.join(current_directory, dir))
            if os.path.isdir(new_dir):
                current_directory = new_dir
            else:
                print(f"does not exists {dir}")
        # if no input after cd
        elif command == "cd":
            print(current_directory)    
        elif command == "exit":
            result = subprocess.run([bat_exit], shell=True)
            if result.returncode ==99:
                break

        else:
            print("command does not exists")

