help_text = (
                "Supported commands:\n"
                "  ls [dir]          - List directory contents\n"
                "  hello             - Print greeting and username\n"
                "  hexdump <file>    - Print file in hex format\n"
                "  grep <term> [file] and if in | no need for file- Search for text pattern\n" 
                "  cd [dir]          - Change current directory\n"
                "  exit              - Exit the shell\n"
                "  <cmd1> | <cmd2>   - Pipe output between commands\n"
                "  <cmd> > <file>    - Redirect output to file"
            )
print(help_text)